declare module 'react.timer';
declare module 'react-audio-player';